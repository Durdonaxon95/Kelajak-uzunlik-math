# Kelajak Markazi Mini App — Uzunlik detektivlari

## Tarkibi
- `index.html` — mobil qurilmaga mos o‘zbekcha matematika o‘yini.
- 1–4-sinf uchun uzunlikka doir masalalar.
- Javobni tekshirish, yechim va ishora.
- Har to‘g‘ri javob uchun 10 ball.
- Natija, jami ball va eng yaxshi foiz.

## Muhim cheklov
Bu boshlang‘ich statik versiya. Natijalar faqat o‘sha qurilma/brauzerning localStorage xotirasida saqlanadi. Umumiy reyting, Telegram ID bo‘yicha o‘quvchini tanish va o‘qituvchi uchun markaziy hisobot kerak bo‘lsa, server/backend qo‘shish lozim.

## 1. HTTPS hostingga joylash (GitHub Pages)
1. https://github.com/ saytida hisob oching yoki kiring.
2. New repository yarating, masalan `kelajak-markazi-miniapp`.
3. `index.html` faylini repository root qismiga yuklang: Add file → Upload files → Commit changes.
4. Repository → Settings → Pages bo‘limini oching.
5. Build and deployment: **Deploy from a branch**.
6. Branch `main`, folder `/(root)` ni tanlab Save bosing.
7. Bir oz kuting. Sayt manzili `https://USERNAME.github.io/REPOSITORY/` ko‘rinishida bo‘ladi. Shu manzilni tekshiring.

## 2. Telegram Mini App bilan ulash
1. Telegramda `@BotFather` ni oching.
2. `/mybots` yuborib `KelajakMarkazi_bot` ni tanlang.
3. Mini App/Web App sozlamalarini tanlang. BotFather menyusida bo‘lmasa, `/newapp` buyrug‘ini sinab ko‘ring; BotFather ko‘rsatmalariga amal qiling.
4. App nomi, tavsifi va HTTPS URL ni kiriting.
5. BotFather ko‘rsatgan Mini App havolasini oling. Asosiy Mini App havolasi ko‘pincha `https://t.me/BOT_USERNAME?startapp` shaklida bo‘ladi; sizga ko‘rsatilgan aniq havoladan foydalaning.
6. Telegram kanalingizga post joylab, shu havolani qo‘shing. Masalan: “🎮 Uzunlik detektivlari boshlandi! O‘yinni oching: [Mini App havolasi]”
7. Havolani telefoningizdagi Telegram ichida ochib sinang.

Mini App kanalga fayl sifatida yuklanmaydi: HTTPS sayt sifatida joylanadi, so‘ng kanal postiga havolasi qo‘shiladi. Telegram bot bilan ulanadigan Mini App uchun BotFather sozlamasi kerak.

## 3. Sinash va yangilash
- Avval `index.html` faylini kompyuterda brauzer bilan ochib tekshirishingiz mumkin.
- GitHub Pages'ga yangilash uchun repository ichidagi `index.html` faylini almashtirib commit qiling.
- Telegram bot tokenini hech qachon HTML faylga yozmang.

## Keyingi bosqich
Agar o‘quvchilar ballari barcha qurilmalarda bir xil ko‘rinsin, admin panel bo‘lsin va natijalar bazada saqlansin desangiz, backend va doimiy hosting qo‘shish kerak.
